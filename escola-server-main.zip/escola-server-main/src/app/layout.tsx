import type { Metadata } from "next";
import { Poppins } from "next/font/google";
import { Toaster } from "@/components/ui/sonner";
import "@/styles/globals.css";
import { AppSidebar } from "@/components/sidebar";
import { SidebarProvider } from "@/components/ui/sidebar";

const poppinsSans = Poppins({
  variable: "--font-poppins",
  subsets: ["latin"],
  weight: ["400"],
});

export const metadata: Metadata = {
  title: "Escola",
  description: "Trabalho de banco de dados",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body
        className={`${poppinsSans.variable} antialiased text-sm font-normal `}
      >
        <SidebarProvider>
          <AppSidebar />
          <main className="flex flex-col w-full items-center justify-start gap-4">
            {children}
          </main>
        </SidebarProvider>
        <Toaster richColors theme="light" />
      </body>
    </html>
  );
}
