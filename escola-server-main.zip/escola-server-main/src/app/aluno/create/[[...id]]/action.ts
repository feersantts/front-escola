"use server";

import { serverFetch } from "@/lib/fetch";
import { phoneMask } from "@/lib/mask-options";
import { AlunoCreate } from "@/schema";
import { format } from "@react-input/mask";

export interface Aluno {
  id: number;
  nome: string;
  data_nascimento: string;
  telefone: string;
  responsavel: string;
}

export async function deleteAlunoAction(id: number) {
  try {
    await serverFetch(`aluno/${id}`, {
      method: "DELETE",
    });
    return {
      success: true,
      message: "Aluno removido com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em removido aluno:", error);
    return {
      success: false,
      message: error.message || "Falha em removido aluno",
    };
  }
}

export async function updateAlunoAction(id: string, data: AlunoCreate) {
  const { telefone } = data;
  const submit = {
    ...data,
    telefone: telefone.replace(/\D/g, ""),
  };
  try {
    await serverFetch(`aluno/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(submit),
    });
    return {
      success: true,
      message: "Aluno atualizado com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em atualizar aluno:", error);
    return {
      success: false,
      message: error.message || "Falha em atualizar aluno",
    };
  }
}

export async function getAlunosByIdAction(id: string) {
  try {
    const response = await serverFetch<Aluno>(`aluno/${id}`, {
      method: "GET",
    });

    const { telefone, ...rest } = response;
    const data = { ...rest, telefone: format(telefone, phoneMask) };

    return {
      success: true,
      message: "Sucesso ao buscar aluno",
      data: data,
    };
  } catch (error: any) {
    console.error("Erro ao buscar aluno:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar aluno",
      data: undefined,
    };
  }
}

export async function getAllAlunosAction() {
  try {
    const response = await serverFetch<Aluno[]>(`aluno`, {
      method: "GET",
    });
    return {
      success: true,
      message: "Sucesso ao buscar alunos",
      data: response,
    };
  } catch (error: any) {
    console.error("Erro ao buscar alunos:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar alunos",
      data: [],
    };
  }
}

export async function createAlunoAction(data: AlunoCreate) {
  const { telefone } = data;
  const submit = {
    ...data,
    telefone: telefone.replace(/\D/g, ""),
  };

  try {
    await serverFetch(`aluno`, {
      body: JSON.stringify(submit),
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    return {
      success: true,
      message: "Aluno cadastrado com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em cadastrar aluno:", error);
    return {
      success: true,
      message: error.message || "Falha em cadastrar aluno",
    };
  }
}
