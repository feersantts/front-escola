import FormCreateAluno from "@/components/form/aluno";
import { getAlunosByIdAction } from "./action";

export default async function Aluno({ params }: { params: { id?: string[] } }) {
  const { id } = await params;

  const props = {
    id: id?.[0],
    isEdit: !!id,
    values: !!id
      ? (await getAlunosByIdAction(id[0])).data!
      : { nome: "", data_nascimento: "", telefone: "", responsavel: "" },
  };

  return (
    <div className="container flex flex-col items-center justify-center min-h-screen">
      <h1 className="text-2xl font-bold mb-4">
        {props.isEdit ? "Editar Aluno" : "Cadatrar novo Aluno"}
      </h1>
      <p className="text-gray-600 mb-8">
        {props.isEdit
          ? "Preencha os campos abaixo para editar a aluno."
          : "Preencha os campos abaixo para criar uma nova aluno."}
      </p>      <FormCreateAluno {...props} />
    </div>
  );
}
