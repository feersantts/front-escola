import AlunosTable from "@/components/table/alunos";
import DisciplinaTable from "@/components/table/disciplina";
import MatriculaTable from "@/components/table/matricula";
import ProfessorTable from "@/components/table/professor";
import TurmaTable from "@/components/table/turma";

export default function Dashboard() {
  return (
    <div className="container grid grid-cols-1 gap-8 max-w-[900px] mx-auto p-6">
      <AlunosTable />
      <ProfessorTable />
      <DisciplinaTable />
      <MatriculaTable />
      <TurmaTable />
    </div>
  );
}
