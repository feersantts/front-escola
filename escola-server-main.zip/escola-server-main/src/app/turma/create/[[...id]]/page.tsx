import { getAllDisciplinasAction } from "@/app/disciplina/create/[[...id]]/action";
import { getAllProfessorsAction } from "@/app/professor/create/[[...id]]/action";
import FormCreateTurma from "@/components/form/turma";
import { getTurmasByIdAction } from "./action";

export default async function Turma({ params }: { params: { id?: string[] } }) {
  const { id } = await params;

  const props = {
    id: id?.[0],
    isEdit: !!id,
    professores: (await getAllProfessorsAction()).data,
    disciplinas: (await getAllDisciplinasAction()).data,
    values: !!id
      ? (await getTurmasByIdAction(id[0])).data!
      : { nome: "", ano: "", professor_id: "", disciplina_id: "" },
  };

  return (
        <div className="container flex flex-col items-center justify-center min-h-screen">
      <h1 className="text-2xl font-bold mb-4">
        {props.isEdit ? "Editar Turma" : "Cadatrar novo Turma"}
      </h1>
      <p className="text-gray-600 mb-8">
        {props.isEdit
          ? "Preencha os campos abaixo para editar a turma."
          : "Preencha os campos abaixo para criar uma nova turma."}
      </p>
      <FormCreateTurma {...props} />
    </div>
  );
}
