"use server";

import { serverFetch } from "@/lib/fetch";
import { TurmaCreate } from "@/schema";

export interface Turma {
  id: number;
  nome: string;
  ano: string;
  professor_id: string;
  disciplina_id: string;
  matriculas: any
  professor?: {
    nome: string | null;
  } | null;
  disciplina?: {
    nome: string | null;
  } | null;
}

export async function deleteTurmaAction(id: string) {
  try {
    await serverFetch(`turma/${id}`, {
      method: "DELETE",
    });
    return {
      success: true,
      message: "Turma removido com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em removido turma:", error);
    return {
      success: false,
      message: error.message || "Falha em removido turma",
    };
  }
}

export async function updateTurmaAction(id: string, data: TurmaCreate) {
  const { professor_id, disciplina_id, ano } = data;
  const submit = {
    ...data,
    ano: Number(ano),
    professor_id: Number(professor_id),
    disciplina_id: Number(disciplina_id),
  };
  try {
    await serverFetch(`turma/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(submit),
    });
    return {
      success: true,
      message: "Turma atualizado com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em atualizar turma:", error);
    return {
      success: false,
      message: error.message || "Falha em atualizar turma",
    };
  }
}

export async function getTurmasByIdAction(id: string) {
  try {
    const response = await serverFetch<Turma>(`turma/${id}`, {
      method: "GET",
    });

    const { professor_id, disciplina_id, ano, ...rest } = response;
    const data = {
      ...rest,
      ano: ano.toString(),
      professor_id: professor_id.toString(),
      disciplina_id: disciplina_id.toString(),
    };

    return {
      success: true,
      message: "Sucesso ao buscar turma",
      data: data,
    };
  } catch (error: any) {
    console.error("Erro ao buscar turma:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar turma",
      data: undefined,
    };
  }
}

export async function getAlunosByTurmaAction(id: number) {
  try {
    const response = await serverFetch<Turma>(`turma/${id}/alunos`, {
      method: "GET",
    });

    return {
      success: true,
      message: "Sucesso ao buscar turma",
      data: response,
    };
  } catch (error: any) {
    console.error("Erro ao buscar turma:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar turma",
      data: undefined,
    };
  }
}

export async function getAllTurmasAction() {
  try {
    const response = await serverFetch<Turma[]>(`turma`, {
      method: "GET",
    });
    return {
      success: true,
      message: "Sucesso ao buscar turmas",
      data: response,
    };
  } catch (error: any) {
    console.error("Erro ao buscar turmas:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar turmas",
      data: [],
    };
  }
}

export async function createTurmaAction(data: TurmaCreate) {
  const { professor_id, disciplina_id, ano } = data;
  const submit = {
    ...data,
    ano: Number(ano),
    professor_id: Number(professor_id),
    disciplina_id: Number(disciplina_id),
  };
  try {
    await serverFetch(`turma`, {
      body: JSON.stringify(submit),
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    return {
      success: true,
      message: "Turma cadastrado com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em cadastrar turma:", error);
    return {
      success: true,
      message: error.message || "Falha em cadastrar turma",
    };
  }
}
