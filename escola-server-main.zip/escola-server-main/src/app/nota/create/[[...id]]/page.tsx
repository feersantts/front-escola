import { getAllAlunosAction } from "@/app/aluno/create/[[...id]]/action";
import { getAllDisciplinasAction } from "@/app/disciplina/create/[[...id]]/action";
import FormCreateNota from "@/components/form/nota";
import { Bimestre } from "@/schema";
import { getNotasByIdAction } from "./action";

export default async function Nota({ params }: { params: { id?: string[] } }) {
  const { id } = await params;

  const props = {
    id: id?.[0],
    isEdit: !!id,
    alunos: (await getAllAlunosAction()).data,
    disciplinas: (await getAllDisciplinasAction()).data,
    values: !!id
      ? (await getNotasByIdAction(id[0])).data!
      : { aluno_id: "", disciplina_id: "", valor: "", bimestre: "" as Bimestre },
  };

  return (
    <div className="container flex flex-col items-center justify-center min-h-screen">
      <h1 className="text-2xl font-bold mb-4">
        {props.isEdit ? "Editar Nota" : "Cadatrar novo Nota"}
      </h1>
      <p className="text-gray-600 mb-8">
        {props.isEdit
          ? "Preencha os campos abaixo para editar a nota."
          : "Preencha os campos abaixo para criar uma nova nota."}
      </p>      <FormCreateNota {...props} />
    </div>
  )
}
