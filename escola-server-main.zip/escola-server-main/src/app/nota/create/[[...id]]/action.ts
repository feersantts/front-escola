"use server";

import { serverFetch } from "@/lib/fetch";
import { Bimestre, NotaCreate } from "@/schema";

export interface Nota {
  id: number;
  aluno_id: string;
  disciplina_id: string;
  bimestre: Bimestre;
  valor: string;
}

export async function deleteNotaAction(id: string) {
  try {
    await serverFetch(`nota/${id}`, {
      method: "DELETE",
    });
    return {
      success: true,
      message: "Nota removido com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em removido nota:", error);
    return {
      success: false,
      message: error.message || "Falha em removido nota",
    };
  }
}

export async function updateNotaAction(id: string, data: NotaCreate) {
  const { aluno_id, disciplina_id, valor } = data;
  const submit = {
    ...data,
    valor: Number(valor).toFixed(1),
    aluno_id: Number(aluno_id),
    disciplina_id: Number(disciplina_id),
  };
  try {
    await serverFetch(`nota/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(submit),
    });
    return {
      success: true,
      message: "Nota atualizado com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em atualizar nota:", error);
    return {
      success: false,
      message: error.message || "Falha em atualizar nota",
    };
  }
}

export async function getNotasByIdAction(id: string) {
  try {
    const response = await serverFetch<Nota>(`nota/${id}`, {
      method: "GET",
    });

    const { aluno_id, disciplina_id, valor, ...rest } = response;
    const data = {
      ...rest,
      valor: valor.toString(),
      aluno_id: aluno_id.toString(),
      disciplina_id: disciplina_id.toString(),
    };

    return {
      success: true,
      message: "Sucesso ao buscar nota",
      data: data,
    };
  } catch (error: any) {
    console.error("Erro ao buscar nota:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar nota",
      data: undefined,
    };
  }
}

export async function getAllNotasAction() {
  try {
    const response = await serverFetch<Nota[]>(`nota`, {
      method: "GET",
    });
    return {
      success: true,
      message: "Sucesso ao buscar notas",
      data: response,
    };
  } catch (error: any) {
    console.error("Erro ao buscar notas:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar notas",
      data: [],
    };
  }
}

export async function createNotaAction(data: NotaCreate) {
  const { aluno_id, disciplina_id, valor } = data;
  const submit = {
    ...data,
    valor: Number(valor).toFixed(1),
    aluno_id: Number(aluno_id),
    disciplina_id: Number(disciplina_id),
  };
  try {
    await serverFetch(`nota`, {
      body: JSON.stringify(submit),
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    return {
      success: true,
      message: "Nota cadastrado com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em cadastrar nota:", error);
    return {
      success: true,
      message: error.message || "Falha em cadastrar nota",
    };
  }
}
