import AlunosTurmaTable from "@/components/table/turma-alunos";
import { getAllTurmasAction } from "../turma/create/[[...id]]/action";

export default async function Relatorio() {
  const turmas = (await getAllTurmasAction()).data;

  return (
    <div className="container flex flex-col items-center justify-center mt-12">
      <AlunosTurmaTable turmas={turmas} />
    </div>
  );
}
