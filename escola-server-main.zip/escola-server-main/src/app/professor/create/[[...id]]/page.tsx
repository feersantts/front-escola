import FormCreateProfessor from "@/components/form/professor";
import { getProfessorsByIdAction } from "./action";

export default async function Professor({
  params,
}: {
  params: { id?: string[] };
}) {
  const { id } = await params;

  const props = {
    id: id?.[0],
    isEdit: !!id,
    values: !!id
      ? (await getProfessorsByIdAction(id[0])).data!
      : { nome: "", cpf: "", especialidade: "" },
  };

  return (
    <div className="container flex flex-col items-center justify-center min-h-screen">
      <h1 className="text-2xl font-bold mb-4">
        {props.isEdit ? "Editar Professor" : "Cadatrar novo Professor"}
      </h1>
      <p className="text-gray-600 mb-8">
        {props.isEdit
          ? "Preencha os campos abaixo para editar a professor."
          : "Preencha os campos abaixo para criar uma nova professor."}
      </p>      <FormCreateProfessor {...props} />
    </div>
  );
}
