"use server";

import { serverFetch } from "@/lib/fetch";
import { cpfMask } from "@/lib/mask-options";
import { ProfessorCreate } from "@/schema";
import { format } from "@react-input/mask";

export interface Professor {
  id: number;
  nome: string;
  cpf: string;
  especialidade: string;
}

export async function deleteProfessorAction(id: string) {
  try {
    await serverFetch(`professor/${id}`, {
      method: "DELETE",
    });
    return {
      success: true,
      message: "Professor removido com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em removido professor:", error);
    return {
      success: false,
      message: error.message || "Falha em removido professor",
    };
  }
}

export async function updateProfessorAction(id: string, data: ProfessorCreate) {
  const { cpf } = data;
  const submit = {
    ...data,
    cpf: cpf.replace(/\D/g, ""),
  };
  try {
    await serverFetch(`professor/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(submit),
    });
    return {
      success: true,
      message: "Professor atualizado com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em atualizar professor:", error);
    return {
      success: false,
      message: error.message || "Falha em atualizar professor",
    };
  }
}

export async function getProfessorsByIdAction(id: string) {
  try {
    const response = await serverFetch<Professor>(`professor/${id}`, {
      method: "GET",
    });

    const { cpf, ...rest } = response;
    const data = { ...rest, cpf: format(cpf, cpfMask) };

    return {
      success: true,
      message: "Sucesso ao buscar professor",
      data: data,
    };
  } catch (error: any) {
    console.error("Erro ao buscar professor:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar professor",
      data: undefined,
    };
  }
}

export async function getAllProfessorsAction() {
  try {
    const response = await serverFetch<Professor[]>(`professor`, {
      method: "GET",
    });
    return {
      success: true,
      message: "Sucesso ao buscar professors",
      data: response,
    };
  } catch (error: any) {
    console.error("Erro ao buscar professors:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar professors",
      data: [],
    };
  }
}

export async function createProfessorAction(data: ProfessorCreate) {
  const { cpf } = data;
  const submit = {
    ...data,
    cpf: cpf.replace(/\D/g, ""),
  };
  try {
    await serverFetch(`professor`, {
      body: JSON.stringify(submit),
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    return {
      success: true,
      message: "Professor cadastrado com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em cadastrar professor:", error);
    return {
      success: true,
      message: error.message || "Falha em cadastrar professor",
    };
  }
}
