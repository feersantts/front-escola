import { getAllAlunosAction } from "@/app/aluno/create/[[...id]]/action";
import { getAllTurmasAction } from "@/app/turma/create/[[...id]]/action";
import FormCreateMatricula from "@/components/form/matricula";
import { getMatriculasByIdAction } from "./action";

export default async function Matricula({
  params,
}: {
  params: { id?: string[] };
}) {
  const { id } = await params;

  const props = {
    id: id?.[0],
    isEdit: !!id,
    alunos: (await getAllAlunosAction()).data,
    turmas: (await getAllTurmasAction()).data,
    values: !!id
      ? (await getMatriculasByIdAction(id[0])).data!
      : { aluno_id: "", turma_id: "" },
  };

  return (
    <div className="container flex flex-col items-center justify-center min-h-screen">
      <h1 className="text-2xl font-bold mb-4">
        {props.isEdit ? "Editar Matrícula" : "Cadatrar novo Matrícula"}
      </h1>
      <p className="text-gray-600 mb-8">
        {props.isEdit
          ? "Preencha os campos abaixo para editar a matrícula."
          : "Preencha os campos abaixo para criar uma nova matrícula."}
      </p>
      <FormCreateMatricula {...props} />
    </div>
  );
}
