"use server";

import { serverFetch } from "@/lib/fetch";
import { MatriculaCreate } from "@/schema";

export interface Matricula {
  id: number;
  aluno_id: string;
  turma_id: string;
  aluno?: {
    nome: string | null;
  } | null;
  turma?: {
    nome: string | null;
  } | null;
}

export async function deleteMatriculaAction(id: string) {
  try {
    await serverFetch(`matricula/${id}`, {
      method: "DELETE",
    });
    return {
      success: true,
      message: "Matricula removido com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em removido matricula:", error);
    return {
      success: false,
      message: error.message || "Falha em removido matricula",
    };
  }
}

export async function updateMatriculaAction(id: string, data: MatriculaCreate) {
  const { aluno_id, turma_id } = data;
  const submit = {
    ...data,
    aluno_id: Number(aluno_id),
    turma_id: Number(turma_id),
  };
  try {
    await serverFetch(`matricula/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(submit),
    });
    return {
      success: true,
      message: "Matricula atualizado com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em atualizar matricula:", error);
    return {
      success: false,
      message: error.message || "Falha em atualizar matricula",
    };
  }
}

export async function getMatriculasByIdAction(id: string) {
  try {
    const response = await serverFetch<Matricula>(`matricula/${id}`, {
      method: "GET",
    });

    const { aluno_id, turma_id, ...rest } = response;
    const data = {
      ...rest,
      aluno_id: aluno_id.toString(),
      turma_id: turma_id.toString(),
    };

    return {
      success: true,
      message: "Sucesso ao buscar matricula",
      data: data,
    };
  } catch (error: any) {
    console.error("Erro ao buscar matricula:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar matricula",
      data: undefined,
    };
  }
}

export async function getAllMatriculasAction() {
  try {
    const response = await serverFetch<Matricula[]>(`matricula`, {
      method: "GET",
    });
    return {
      success: true,
      message: "Sucesso ao buscar matriculas",
      data: response,
    };
  } catch (error: any) {
    console.error("Erro ao buscar matriculas:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar matriculas",
      data: [],
    };
  }
}

export async function createMatriculaAction(data: MatriculaCreate) {
  const { aluno_id, turma_id } = data;
  const submit = {
    ...data,
    aluno_id: Number(aluno_id),
    turma_id: Number(turma_id),
  };
  try {
    await serverFetch(`matricula`, {
      body: JSON.stringify(submit),
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    return {
      success: true,
      message: "Matricula cadastrado com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em cadastrar matricula:", error);
    return {
      success: true,
      message: error.message || "Falha em cadastrar matricula",
    };
  }
}
