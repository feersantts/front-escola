"use server";

import { serverFetch } from "@/lib/fetch";
import { DisciplinaCreate } from "@/schema";

export interface Disciplina {
  id: number;
  nome: string;
  carga_horaria: number;
}

export async function deleteDisciplinaAction(id: string) {
  try {
    await serverFetch(`disciplina/${id}`, {
      method: "DELETE",
    });
    return {
      success: true,
      message: "Disciplina removido com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em removido disciplina:", error);
    return {
      success: false,
      message: error.message || "Falha em removido disciplina",
    };
  }
}

export async function updateDisciplinaAction(
  id: string,
  data: DisciplinaCreate
) {
  const { carga_horaria } = data;
  const submit = {
    ...data,
    carga_horaria: Number(carga_horaria),
  };
  try {
    await serverFetch(`disciplina/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(submit),
    });
    return {
      success: true,
      message: "Disciplina atualizado com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em atualizar disciplina:", error);
    return {
      success: false,
      message: error.message || "Falha em atualizar disciplina",
    };
  }
}

export async function getDisciplinasByIdAction(id: string) {
  try {
    const response = await serverFetch<Disciplina>(`disciplina/${id}`, {
      method: "GET",
    });

        const {carga_horaria, ...rest} = response
        const data = {...rest, carga_horaria: carga_horaria.toString()}

    return {
      success: true,
      message: "Sucesso ao buscar disciplina",
      data: data,
    };
  } catch (error: any) {
    console.error("Erro ao buscar disciplina:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar disciplina",
      data: undefined,
    };
  }
}

export async function getAllDisciplinasAction() {
  try {
    const response = await serverFetch<Disciplina[]>(`disciplina`, {
      method: "GET",
    });
    return {
      success: true,
      message: "Sucesso ao buscar disciplinas",
      data: response,
    };
  } catch (error: any) {
    console.error("Erro ao buscar disciplinas:", error);
    return {
      success: false,
      message: error.message || "Falha ao buscar disciplinas",
      data: [],
    };
  }
}

export async function createDisciplinaAction(data: DisciplinaCreate) {
  const { carga_horaria } = data;
  const submit = {
    ...data,
    carga_horaria: Number(carga_horaria),
  };
  try {
    await serverFetch(`disciplina`, {
      body: JSON.stringify(submit),
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    return {
      success: true,
      message: "Disciplina cadastrado com sucesso",
    };
  } catch (error: any) {
    console.error("Erro em cadastrar disciplina:", error);
    return {
      success: true,
      message: error.message || "Falha em cadastrar disciplina",
    };
  }
}
