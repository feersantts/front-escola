import FormCreateDiciplina from "@/components/form/diciplina";
import { getDisciplinasByIdAction } from "./action";

export default async function Professor({
  params,
}: {
  params: { id?: string[] };
}) {
  const { id } = await params;

  const props = {
    id: id?.[0],
    isEdit: !!id,
    values: !!id
      ? (await getDisciplinasByIdAction(id[0])).data!
      : { nome: "", carga_horaria: "" },
  };
  return (
    <div className="container flex flex-col items-center justify-center min-h-screen">
      <h1 className="text-2xl font-bold mb-4">
        {props.isEdit ? "Editar Disciplina" : "Cadatrar nova Disciplina"}
      </h1>
      <p className="text-gray-600 mb-8">
        {props.isEdit
          ? "Preencha os campos abaixo para editar a disciplina."
          : "Preencha os campos abaixo para criar uma nova disciplina."}
      </p>
      <FormCreateDiciplina {...props} />
    </div>
  );
}
