"use server";

class ApiError extends Error {
  constructor(
    public status: number,
    public message: string,
    public data?: any
  ) {
    super(message);
    this.name = "ApiError";
  }
}

export async function serverFetch<T = any>(
  input: RequestInfo | URL,
  init?: RequestInit
): Promise<T> {
  const headers = new Headers(init?.headers);
  
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_SERVER}${input}`, {
      ...init,
      headers,
    });

    const data = await response.json();

    if (!response.ok) {
      throw new ApiError(response.status, response.statusText, data);
    }

    return data;
  } catch (error: any) {
    if (error instanceof ApiError) {
      console.error(`API Error - Status: ${error.status}`, error.message, error.data);
      throw error;
    }

    console.error('Network error', error);
    throw new ApiError(500, 'Network error', { 
      originalError: error.message 
    });
  }
}