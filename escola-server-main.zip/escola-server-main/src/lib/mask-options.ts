export const phoneMask = {
  mask: "(__) _____-____",
  replacement: { _: /\d/ },
};

export const cpfMask = {
  mask: "___.___.___-__",
  replacement: { _: /\d/ },
};
