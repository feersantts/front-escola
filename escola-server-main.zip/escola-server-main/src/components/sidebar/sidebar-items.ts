import { Folders, Home, Layers, LayoutDashboard, Library, Users } from "lucide-react"

export const sidebarItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: Home,
  },
  {
    title: "Aluno",
    url: "/aluno/create",
    icon: Users,
  },
  {
    title: "Professor",
    url: "/professor/create",
    icon: Users,
  },
  {
    title: "Disciplina",
    url: "/disciplina/create",
    icon: LayoutDashboard,
  },
  {
    title: "Turma",
    url: "/turma/create",
    icon: Library,
  },
  {
    title: "Matrícula",
    url: "/matricula/create",
    icon: Layers,
  },
  {
    title: "Nota",
    url: "/nota/create",
    icon: Folders,
  },
  {
    title: "Alunos de uma Turma",
    url: "/relatorio",
    icon: Folders,
  },
]