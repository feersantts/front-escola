"use client";

import {
  createDisciplinaAction,
  updateDisciplinaAction,
} from "@/app/disciplina/create/[[...id]]/action";
import ButtonPending from "@/components/custom/button/pending";
import Input from "@/components/custom/input/input";
import { Form } from "@/components/ui/form";
import { DisciplinaCreate } from "@/schema";
import { DisciplinaCreateSchema } from "@/schema/diciplina";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { toast } from "sonner";

type PropsType = {
  id?: string;
  isEdit: boolean;
  values: DisciplinaCreate;
};

export default function FormCreateDiciplina({ values, isEdit, id }: PropsType) {
  const form = useForm<DisciplinaCreate>({
    resolver: zodResolver(DisciplinaCreateSchema),
    defaultValues: values,
  });

  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting: state },
  } = form;

  const onSubmit = async (data: DisciplinaCreate) => {
    const resp = isEdit
      ? await updateDisciplinaAction(id!, data)
      : await createDisciplinaAction(data);

    if (resp.success) {
      return toast.success(resp.message);
    }
    return toast.error(resp.message);
  };

  return (
    <Form {...form}>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-col gap-4 w-full max-w-xl"
      >
        <Input
          control={control}
          name="nome"
          label="Nome da diciplina"
          error={errors.nome?.message}
        />

        <Input
          control={control}
          name="carga_horaria"
          label="Digite a carga horária"
          error={errors.carga_horaria?.message}
          type="number"
        />

        <div className="space-x-4">
          <ButtonPending type="submit" isPending={state} label="Salvar" />
        </div>
      </form>
    </Form>
  );
}
