"use client";

import { createProfessorAction, updateProfessorAction } from "@/app/professor/create/[[...id]]/action";
import ButtonPending from "@/components/custom/button/pending";
import Input from "@/components/custom/input/input";
import InputMask from "@/components/custom/input/mask";
import { Form } from "@/components/ui/form";
import { cpfMask } from "@/lib/mask-options";
import { ProfessorCreate } from "@/schema";
import { ProfessorCreateSchema } from "@/schema/professor";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { toast } from "sonner";

type PropsType = {
  id?: string;
  isEdit: boolean;
  values: ProfessorCreate;
};

export default function FormCreateProfessor({ values, isEdit, id }: PropsType) {
  const form = useForm<ProfessorCreate>({
    resolver: zodResolver(ProfessorCreateSchema),
    defaultValues: values,
  });

  console.log(values)

  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting: state },
  } = form;

  const onSubmit = async (data: ProfessorCreate) => {
    const resp = isEdit
      ? await updateProfessorAction(id!, data)
      : await createProfessorAction(data);

    if (resp.success) {
      return toast.success(resp.message);
    }
    return toast.error(resp.message);
  };

  return (
    <Form {...form}>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-col gap-4 w-full max-w-xl"
      >
        <Input
          control={control}
          name="nome"
          label="Nome do professor"
          error={errors.nome?.message}
        />

        <InputMask
          control={control}
          name="cpf"
          label="Digite o CPF"
          error={errors.cpf?.message}
          {...cpfMask}
        />

        <Input
          control={control}
          name="especialidade"
          label="Digite a especialidade"
          error={errors.especialidade?.message}
        />

        <div className="space-x-4">
          <ButtonPending type="submit" isPending={state} label="Salvar" />
        </div>
      </form>
    </Form>
  );
}
