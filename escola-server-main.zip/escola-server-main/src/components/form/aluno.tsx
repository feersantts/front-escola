"use client";

import {
  createAlunoAction,
  updateAlunoAction,
} from "@/app/aluno/create/[[...id]]/action";
import ButtonPending from "@/components/custom/button/pending";
import Input from "@/components/custom/input/input";
import InputMask from "@/components/custom/input/mask";
import { Form } from "@/components/ui/form";
import { phoneMask } from "@/lib/mask-options";
import { AlunoCreate } from "@/schema";
import { AlunoCreateSchema } from "@/schema/aluno";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { toast } from "sonner";

type PropsType = {
  id?: string;
  isEdit: boolean;
  values: AlunoCreate;
};

export default function FormCreateAluno({ values, isEdit, id }: PropsType) {
  const form = useForm<AlunoCreate>({
    resolver: zodResolver(AlunoCreateSchema),
    defaultValues: values,
  });

  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting: state },
  } = form;

  const onSubmit = async (data: AlunoCreate) => {
    const resp = isEdit
      ? await updateAlunoAction(id!, data)
      : await createAlunoAction(data);

    if (resp.success) {
      return toast.success(resp.message);
    }
    return toast.error(resp.message);
  };

  return (
    <Form {...form}>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-col gap-4 w-full max-w-xl"
      >
        <Input
          control={control}
          name="nome"
          label="Nome do aluno"
          error={errors.nome?.message}
        />

        <div className="flex gap-4">
          <Input
            control={control}
            name="data_nascimento"
            label="Data de nascimento"
            error={errors.data_nascimento?.message}
            type="date"
          />

          <InputMask
            control={control}
            name="telefone"
            label="Telefone"
            error={errors.telefone?.message}
            {...phoneMask}
          />
        </div>

        <Input
          control={control}
          name="responsavel"
          label="Nome do responsável"
          error={errors.responsavel?.message}
        />

        <div className="space-x-4">
          <ButtonPending type="submit" isPending={state} label="Salvar" />
        </div>
      </form>
    </Form>
  );
}
