"use client";

import { Disciplina } from "@/app/disciplina/create/[[...id]]/action";
import { Professor } from "@/app/professor/create/[[...id]]/action";
import ButtonPending from "@/components/custom/button/pending";
import Select from "@/components/custom/select/select";
import Input from "@/components/custom/input/input";
import { Form } from "@/components/ui/form";
import { TurmaCreate } from "@/schema";
import { TurmaCreateSchema } from "@/schema/turma";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import {
  createTurmaAction,
  updateTurmaAction,
} from "@/app/turma/create/[[...id]]/action";
import { toast } from "sonner";

type PropsType = {
  id?: string;
  isEdit: boolean;
  values: TurmaCreate;
  professores: Professor[];
  disciplinas: Disciplina[];
};

export default function FormCreateTurma({
  values,
  isEdit,
  id,
  disciplinas,
  professores,
}: PropsType) {
  const form = useForm<TurmaCreate>({
    resolver: zodResolver(TurmaCreateSchema),
    defaultValues: values,
  });

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting: state },
  } = form;

  const onSubmit = async (data: TurmaCreate) => {
    const resp = isEdit
      ? await updateTurmaAction(id!, data)
      : await createTurmaAction(data);

    if (resp.success) {
      reset();
      return toast.success(resp.message);
    }
    return toast.error(resp.message);
  };

  return (
    <Form {...form}>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-col gap-4 w-full max-w-xl"
      >
        <Input
          control={control}
          name="nome"
          label="Nome da turma"
          error={errors.nome?.message}
        />

        <Input
          control={control}
          name="ano"
          label="Digite o ano"
          error={errors.ano?.message}
          type="number"
        />

        <Select
          control={control}
          name="professor_id"
          label="Selecione um professor"
          error={errors?.professor_id?.message}
          items={professores?.map((item) => ({
            value: item.id.toString(),
            label: item.nome,
          }))}
        />

        <Select
          control={control}
          name="disciplina_id"
          label="Selecione uma disciplina"
          error={errors?.disciplina_id?.message}
          items={disciplinas?.map((item) => ({
            value: item.id.toString(),
            label: item.nome,
          }))}
        />

        <div className="space-x-4">
          <ButtonPending type="submit" isPending={state} label="Salvar" />
        </div>
      </form>
    </Form>
  );
}
