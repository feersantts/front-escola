"use client";

import { Aluno } from "@/app/aluno/create/[[...id]]/action";
import { Disciplina } from "@/app/disciplina/create/[[...id]]/action";
import {
  createNotaAction,
  updateNotaAction,
} from "@/app/nota/create/[[...id]]/action";
import ButtonPending from "@/components/custom/button/pending";
import Input from "@/components/custom/input/input";
import Select from "@/components/custom/select/select";
import { Form } from "@/components/ui/form";
import { NotaCreate } from "@/schema";
import { NotaCreateSchema } from "@/schema/nota";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { toast } from "sonner";

type PropsType = {
  id?: string;
  isEdit: boolean;
  values: NotaCreate;
  alunos: Aluno[];
  disciplinas: Disciplina[];
};

export default function FormCreateNota({
  values,
  isEdit,
  id,
  disciplinas,
  alunos,
}: PropsType) {
  const form = useForm<NotaCreate>({
    resolver: zodResolver(NotaCreateSchema),
    defaultValues: values,
  });

  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting: state },
  } = form;

  const onSubmit = async (data: NotaCreate) => {
    const resp = isEdit
      ? await updateNotaAction(id!, data)
      : await createNotaAction(data);

    if (resp.success) {
      // reset()
      return toast.success(resp.message);
    }
    return toast.error(resp.message);
  };

  const bimestres = [
    { value: "B1", label: "1º Bimestre" },
    { value: "B2", label: "2º Bimestre" },
    { value: "B3", label: "3º Bimestre" },
    { value: "B4", label: "4º Bimestre" },
  ];

  return (
    <Form {...form}>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-col gap-4 w-full max-w-xl"
      >
        <Select
          control={control}
          name="bimestre"
          label="Selecione um bimestre"
          error={errors?.bimestre?.message}
          items={bimestres}
        />

        <Select
          control={control}
          name="disciplina_id"
          label="Selecione uma disciplina"
          error={errors?.disciplina_id?.message}
          items={disciplinas?.map((item) => ({
            value: item.id.toString(),
            label: item.nome,
          }))}
        />

        <Select
          control={control}
          name="aluno_id"
          label="Selecione um aluno"
          error={errors?.aluno_id?.message}
          items={alunos?.map((item) => ({
            value: item.id.toString(),
            label: item.nome,
          }))}
        />

        <Input
          control={control}
          name="valor"
          label="Digite a nota"
          error={errors.valor?.message}
          type="number"
        />

        <div className="space-x-4">
          <ButtonPending type="submit" isPending={state} label="Salvar" />
        </div>
      </form>
    </Form>
  );
}
