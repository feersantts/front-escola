"use client";

import { Aluno } from "@/app/aluno/create/[[...id]]/action";
import {
  createMatriculaAction,
  updateMatriculaAction,
} from "@/app/matricula/create/[[...id]]/action";
import { Turma } from "@/app/turma/create/[[...id]]/action";
import ButtonPending from "@/components/custom/button/pending";
import Select from "@/components/custom/select/select";
import { Form } from "@/components/ui/form";
import { MatriculaCreate } from "@/schema";
import { MatriculaCreateSchema } from "@/schema/matricula";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { toast } from "sonner";

type PropsType = {
  id?: string;
  isEdit: boolean;
  values: MatriculaCreate;
  alunos: Aluno[];
  turmas: Turma[];
};

export default function FormCreateMatricula({
  id,
  values,
  isEdit,
  alunos,
  turmas,
}: PropsType) {
  const form = useForm<MatriculaCreate>({
    resolver: zodResolver(MatriculaCreateSchema),
    defaultValues: values,
  });

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting: state },
  } = form;

  const onSubmit = async (data: MatriculaCreate) => {
    const resp = isEdit
      ? await updateMatriculaAction(id!, data)
      : await createMatriculaAction(data);

    if (resp.success) {
      reset();
      return toast.success(resp.message);
    }
    return toast.error(resp.message);
  };

  return (
    <Form {...form}>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-col gap-4 w-full max-w-xl"
      >
        <Select
          control={control}
          name="aluno_id"
          label="Selecione um aluno"
          error={errors?.aluno_id?.message}
          items={alunos.map((item) => ({
            value: item.id.toString(),
            label: item.nome,
          }))}
        />

        <Select
          control={control}
          name="turma_id"
          label="Selecione uma turma"
          error={errors?.aluno_id?.message}
          items={turmas.map((item) => ({
            value: item.id.toString(),
            label: item.nome,
          }))}
        />

        <div className="space-x-4">
          <ButtonPending type="submit" isPending={state} label="Salvar" />
        </div>
      </form>
    </Form>
  );
}
