"use client";

import {
  getAlunosByTurmaAction,
  Turma,
} from "@/app/turma/create/[[...id]]/action";
import { useForm } from "react-hook-form";
import { Form } from "@/components/ui/form";
import { toast } from "sonner";
import Select from "../custom/select/select";
import ButtonPending from "../custom/button/pending";
import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

type PropsType = {
  turmas: Turma[];
};

export default function AlunosTurmaTable({ turmas }: PropsType) {
  const [table, setTable] = useState<any[]>([]);
  const form = useForm<{ turma_id: string }>();

  const {
    control,
    handleSubmit,
    formState: { isSubmitting: state },
  } = form;

  const onSubmit = async (data: { turma_id: string }) => {
    const resp = await getAlunosByTurmaAction(Number(data.turma_id));

    setTable(resp?.data?.matriculas);

    if (resp.success) {
      return toast.success(resp.message);
    }
    return toast.error(resp.message);
  };

  return (
    <>
      <Form {...form}>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex flex-col gap-4 w-full max-w-xl"
        >
          <Select
            control={control}
            name="turma_id"
            label="Selecione uma turma"
            items={turmas.map((item) => ({
              value: item.id.toString(),
              label: item.nome,
            }))}
          />

          <div className="space-x-4">
            <ButtonPending type="submit" isPending={state} label="Enviar" />
          </div>

          {table && table.length > 0 && (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Matricula</TableHead>
                  <TableHead>Aluno</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {table.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>{item.id}</TableCell>
                    <TableCell>{item.aluno.nome}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </form>
      </Form>
    </>
  );
}
