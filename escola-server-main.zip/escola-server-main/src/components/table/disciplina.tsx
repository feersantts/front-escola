"use client";

import {
  deleteDisciplinaAction,
  Disciplina,
  getAllDisciplinasAction,
} from "@/app/disciplina/create/[[...id]]/action";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useEffect, useState } from "react";

export default function DisciplinaTable() {
  const [table, setTable] = useState<Disciplina[]>([]);
  const [loading, setLoading] = useState({
    data: true,
  });

  async function fetchData() {
    setTable((await getAllDisciplinasAction()).data);
    setLoading((prev) => ({ ...prev, data: false }));
  }

  useEffect(() => {
    fetchData();
  }, []);

  async function handleDelete(id: number) {
    await deleteDisciplinaAction(id.toString());
    fetchData();
  }

  if (loading.data) {
    return (
      <div className="flex items-center justify-center w-full h-full">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div>
      <h2 className="font-bold text-xl px-1 mb-2">
        Tabela de disciplinas cadastrados
      </h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Carga horária</TableHead>
            <TableHead>Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {table.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.nome}</TableCell>
              <TableCell>{item.carga_horaria}h</TableCell>
              <TableCell
                className="cursor-pointer text-red-800"
                onClick={() => handleDelete(item.id)}
              >
                Remover
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
