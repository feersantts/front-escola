"use client";

import {
  deleteMatriculaAction,
  getAllMatriculasAction,
  Matricula,
} from "@/app/matricula/create/[[...id]]/action";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useEffect, useState } from "react";

export default function MatriculaTable() {
  const [table, setTable] = useState<Matricula[]>([]);
  const [loading, setLoading] = useState({
    data: true,
  });

  async function fetchData() {
    setTable((await getAllMatriculasAction()).data);
    setLoading((prev) => ({ ...prev, data: false }));
  }

  useEffect(() => {
    fetchData();
  }, []);

  async function handleDelete(id: number) {
    await deleteMatriculaAction(id.toString());
    fetchData();
  }

  if (loading.data) {
    return (
      <div className="flex items-center justify-center w-full h-full">
        <p>Loading...</p>
      </div>
    );
  }

  console.log(table);

  return (
    <div>
      <h2 className="font-bold text-xl px-1 mb-2">
        Tabela de matriculas cadastrados
      </h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Aluno</TableHead>
            <TableHead>Turma</TableHead>
            <TableHead>Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {table.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.aluno?.nome}</TableCell>
              <TableCell>{item.turma?.nome}</TableCell>
              <TableCell
                className="cursor-pointer text-red-800"
                onClick={() => handleDelete(item.id)}
              >
                Remover
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
