"use client";

import {
  Aluno,
  deleteAlunoAction,
  getAllAlunosAction,
} from "@/app/aluno/create/[[...id]]/action";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { phoneMask } from "@/lib/mask-options";
import { format } from "@react-input/mask";
import { useEffect, useState } from "react";

export default function AlunosTable() {
  const [table, setTable] = useState<Aluno[]>([]);
  const [loading, setLoading] = useState({
    data: true,
  });

  async function fetchData() {
    setTable((await getAllAlunosAction()).data);
    setLoading((prev) => ({ ...prev, data: false }));
  }

  useEffect(() => {
    fetchData();
  }, []);

  async function handleDelete(id: number) {
    await deleteAlunoAction(id);
    fetchData();
  }

  if (loading.data) {
    return (
      <div className="flex items-center justify-center w-full h-full">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div>
      <h2 className="font-bold text-xl px-1 mb-2">
        Tabela de alunos cadastrados
      </h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Nascimento</TableHead>
            <TableHead>Telefone</TableHead>
            <TableHead>Responsável</TableHead>
            <TableHead>Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {table.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.nome}</TableCell>
              <TableCell>
                {item.data_nascimento.replace(
                  /([\d]{4})-([\d]{2})-([\d]{2})/,
                  "$3 / $2 / $1"
                )}
              </TableCell>
              <TableCell>{format(item.telefone, phoneMask)}</TableCell>
              <TableCell>{item.responsavel}</TableCell>
              <TableCell
                className="cursor-pointer text-red-800"
                onClick={() => handleDelete(item.id)}
              >
                Remover
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
