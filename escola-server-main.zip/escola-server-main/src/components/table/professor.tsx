"use client";

import {
  deleteProfessorAction,
  getAllProfessorsAction,
  Professor,
} from "@/app/professor/create/[[...id]]/action";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cpfMask } from "@/lib/mask-options";
import { format } from "@react-input/mask";
import { useEffect, useState } from "react";

export default function ProfessorTable() {
  const [table, setTable] = useState<Professor[]>([]);
  const [loading, setLoading] = useState({
    data: true,
  });

  async function fetchData() {
    setTable((await getAllProfessorsAction()).data);
    setLoading((prev) => ({ ...prev, data: false }));
  }

  useEffect(() => {
    fetchData();
  }, []);

  async function handleDelete(id: number) {
    await deleteProfessorAction(id.toString());
    fetchData();
  }

  if (loading.data) {
    return (
      <div className="flex items-center justify-center w-full h-full">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div>
      <h2 className="font-bold text-xl px-1 mb-2">
        Tabela de professores cadastrados
      </h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>CPF</TableHead>
            <TableHead>Especialidade</TableHead>
            <TableHead>Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {table.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.nome}</TableCell>
              <TableCell>{format(item.cpf, cpfMask)}</TableCell>
              <TableCell>{item.especialidade}</TableCell>
              <TableCell
                className="cursor-pointer text-red-800"
                onClick={() => handleDelete(item.id)}
              >
                Remover
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
