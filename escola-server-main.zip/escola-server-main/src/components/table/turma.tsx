"use client";

import { deleteTurmaAction, getAllTurmasAction, Turma } from "@/app/turma/create/[[...id]]/action";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useEffect, useState } from "react";

export default function TurmaTable() {
  const [table, setTable] = useState<Turma[]>([]);
  const [loading, setLoading] = useState({
    data: true,
  });

  async function fetchData() {
    setTable((await getAllTurmasAction()).data);
    setLoading((prev) => ({ ...prev, data: false }));
  }

  useEffect(() => {
    fetchData();
  }, []);

  async function handleDelete(id: number) {
    await deleteTurmaAction(id.toString());
    fetchData();
  }

  if (loading.data) {
    return (
      <div className="flex items-center justify-center w-full h-full">
        <p>Loading...</p>
      </div>
    );
  }

  console.log(table);

  return (
    <div>
      <h2 className="font-bold text-xl px-1 mb-2">
        Tabela de turmas cadastrados
      </h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Professor</TableHead>
            <TableHead>Disciplina</TableHead>
            <TableHead>Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {table.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.professor?.nome}</TableCell>
              <TableCell>{item.disciplina?.nome}</TableCell>
              <TableCell
                className="cursor-pointer text-red-800"
                onClick={() => handleDelete(item.id)}
              >
                Remover
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
