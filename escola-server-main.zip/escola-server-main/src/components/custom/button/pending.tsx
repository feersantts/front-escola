import { Button } from "@/components/ui/button";
import Image from "next/image";

type PropsType = {
  isPending: boolean;
  label?: string;
} & React.ComponentProps<'button'>;

export default function ButtonPending({
  isPending,
  label = "Salvar",
  ...rest
}: PropsType) {
  return (
    <>
      {!isPending ? (
        <Button {...rest} type="submit">
          <p>{label}</p>
        </Button>
      ) : (
        <Image
          src="\assets\ring-resize.svg"
          className="inline-block"
          alt="Loading"
          width="36"
          height="36"
        />
      )}
    </>
  );
}
