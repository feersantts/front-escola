import { z } from "zod";

export const AlunoCreateSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório"),
  data_nascimento: z.string().min(1, "Data de nascimento é obrigatória"),
  telefone: z.string().min(1, "Telefone é obrigatório"),
  responsavel: z.string().min(1, "Responsável é obrigatório"),
});
