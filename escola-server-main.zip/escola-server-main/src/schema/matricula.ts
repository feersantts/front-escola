import { z } from "zod";

export const MatriculaCreateSchema = z.object({
  aluno_id: z.string().min(1, "É necessário selecionar um aluno"),
  turma_id: z.string().min(1, "É necessário selecionar uma turma"),
});