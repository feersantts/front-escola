import { z } from "zod";

export const TurmaCreateSchema = z.object({
  nome: z.string().min(1, "Nome da turma é obrigatório"),
  ano: z.string().min(1, "Ano da turma é obrigatório"),
  professor_id: z.string().min(1, "Professor da turma é obrigatório"),
  disciplina_id: z.string().min(1, "Diciplina da turma é obrigatório")
});