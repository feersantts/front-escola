import { z } from "zod";

export const ProfessorCreateSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório"),
  cpf: z.string().min(11, "CPF deve ter 11 dígitos").max(14, "CPF deve ter no máximo 14 caracteres"),
  especialidade: z.string().min(1, "Especialidade é obrigatória")
});