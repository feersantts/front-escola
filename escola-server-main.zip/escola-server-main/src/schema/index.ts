import { z } from "zod";
import { AlunoCreateSchema } from "./aluno";
import { DisciplinaCreateSchema } from "./diciplina";
import { MatriculaCreateSchema } from "./matricula";
import { BimestreEnum, NotaCreateSchema } from "./nota";
import { TurmaCreateSchema } from "./turma";
import { ProfessorCreateSchema } from "./professor";

export type AlunoCreate = z.infer<typeof AlunoCreateSchema>;
export type DisciplinaCreate = z.infer<typeof DisciplinaCreateSchema>;
export type MatriculaCreate = z.infer<typeof MatriculaCreateSchema>;
export type NotaCreate = z.infer<typeof NotaCreateSchema>;
export type Bimestre = z.infer<typeof BimestreEnum>;
export type ProfessorCreate = z.infer<typeof ProfessorCreateSchema>;
export type TurmaCreate = z.infer<typeof TurmaCreateSchema>;