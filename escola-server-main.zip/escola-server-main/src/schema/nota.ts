import { z } from "zod";

export const BimestreEnum = z.enum(["B1", "B2", "B3", "B4"], {message: "Bimestre inválido"});

export const NotaCreateSchema = z.object({
  aluno_id: z.string().min(1, "Aluno é obrigatório"),
  disciplina_id: z.string().min(1, "Diciplina é obrigatória"),
  bimestre: BimestreEnum,
  valor: z
    .string()
    .min(1, "Nota é obrigatória")
    .refine(
      (value) => {
        const number = parseFloat(value);
        return !isNaN(number) && number >= 0 && number <= 10;
      },
      {
        message: "A nota deve ser um número entre 0 e 10",
      }
    )
    .refine(
      (value) => {
        return Number(value) === 10 || value.length <= 3;
      },
      {
        message: "Valor inválido",
      }
    ),
});
