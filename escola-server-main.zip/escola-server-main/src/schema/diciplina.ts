import { z } from "zod";

export const DisciplinaCreateSchema = z.object({
  nome: z.string().min(1, "Nome da disciplina é obrigatório"),
  carga_horaria: z.string().min(1, "Carga horária é obrigatória")
});