import fastify, { FastifyInstance } from "fastify";
import fastifyMultipart from "@fastify/multipart";
import { registerRoutes } from "./routes";

const app: FastifyInstance = fastify({logger: true});

app.register(fastifyMultipart, {
  limits: {
    fileSize: 10 * 1024 * 1024,
    // Outras opções: https://github.com/fastify/fastify-multipart
  },
});

registerRoutes(app);

app.listen(
  {
    port: 8000,
    host: "localhost",
  },
  (err, address) => {
    if (err) {
      app.log.error(err);
      process.exit(1);
    }
    app.log.info(`Server listening at ${address}`);
  }
);

// http://localhost:8000/
