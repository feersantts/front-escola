export interface Matricula {
  id: number;
  aluno_id: number;
  turma_id: number;
  created_at: Date;
  updated_at: Date;
  aluno?: {
    nome: string | null;
  } | null;
  turma?: {
    nome: string | null;
  } | null;
}

export interface MatriculaCreate {
  aluno_id: number;
  turma_id: number;
}

export interface MatriculaRepository {
  findAll(): Promise<Matricula[]>;
  findById(id: number): Promise<Matricula | null>;
  create(matricula: MatriculaCreate): Promise<Matricula>;
  update(id: number, matricula: MatriculaCreate): Promise<Matricula>;
  delete(id: number): Promise<void>;
  findByAlunoAndTurma(aluno_id: number, turma_id: number): Promise<Matricula | null>;
}