export interface Aluno {
  id: number;
  nome: string;
  data_nascimento: string;
  telefone: string;
  responsavel: string;
}

export interface AlunoCreate {
  nome: string;
  data_nascimento: string;
  telefone: string;
  responsavel: string;
}

export interface AlunoRepository {
  findAll(): Promise<Aluno[]>;
  findById(id: number): Promise<Aluno | null>;
  create(aluno: AlunoCreate): Promise<Aluno>;
  update(id: number, aluno: AlunoCreate): Promise<Aluno>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
}
