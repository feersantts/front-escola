import { $Enums } from "../../generated/prisma/index";
import { Decimal } from "../../generated/prisma/runtime/library";

export type Bimestre = $Enums.Bimestre;

export interface Nota {
  id: number;
  aluno_id: number;
  disciplina_id: number;
  bimestre: Bimestre;
  valor: Decimal;
  created_at: Date;
  updated_at: Date;
}

export interface Nota {
  id: number;
  aluno_id: number;
  disciplina_id: number;
  bimestre: Bimestre;
  valor: Decimal;
  created_at: Date;
  updated_at: Date;
}

export interface NotaCreate {
  aluno_id: number;
  disciplina_id: number;
  bimestre: Bimestre;
  valor: number;
}

export interface NotaRepository {
  create(nota: NotaCreate): Promise<Nota>;
  findById(id: number): Promise<Nota | null>;
  findByAlunoDisciplina(aluno_id: number, disciplina_id: number): Promise<Nota[]>;
  update(id: number, nota: NotaCreate): Promise<Nota>;
  delete(id: number): Promise<void>;
  findByAlunoDisciplinaBimestre(
    aluno_id: number, 
    disciplina_id: number, 
    bimestre: Bimestre
  ): Promise<Nota | null>;
}