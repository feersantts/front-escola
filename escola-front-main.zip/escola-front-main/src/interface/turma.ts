export interface Turma {
  id: number;
  nome: string;
  ano: number;
  professor_id: number;
  disciplina_id: number;
  professor?: {
    nome: string | null;
  } | null;
  disciplina?: {
    nome: string | null;
  } | null;
}

export interface TurmaCreate {
  nome: string;
  ano: number;
  professor_id: number;
  disciplina_id: number;
}

export interface TurmaRepository {
  findAll(): Promise<Turma[]>;
  findById(id: number): Promise<Turma | null>;
  create(turma: TurmaCreate): Promise<Turma>;
  update(id: number, turma: TurmaCreate): Promise<Turma>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
  findAllAlunosByTurma(id: number): Promise<any>;
}
