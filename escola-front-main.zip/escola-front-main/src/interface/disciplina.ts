export interface Disciplina {
  id: number;
  nome: string;
  carga_horaria: number;
}

export interface DisciplinaCreate {
  nome: string;
  carga_horaria: number;
}

export interface DisciplinaRepository {
  findAll(): Promise<Disciplina[]>;
  findById(id: number): Promise<Disciplina | null>;
  create(disciplina: DisciplinaCreate): Promise<Disciplina>;
  update(id: number, disciplina: DisciplinaCreate): Promise<Disciplina>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
}