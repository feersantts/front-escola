export interface Professor {
  id: number;
  nome: string;
  cpf: string;
  especialidade: string;
}

export interface ProfessorCreate {
  nome: string;
  cpf: string;
  especialidade: string;
}

export interface ProfessorRepository {
  findAll(): Promise<Professor[]>;
  findById(id: number): Promise<Pick<Professor, 'nome' | 'id'> | null>;
  create(aluno: ProfessorCreate): Promise<Professor>;
  update(id: number, aluno: ProfessorCreate): Promise<Professor>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
}
