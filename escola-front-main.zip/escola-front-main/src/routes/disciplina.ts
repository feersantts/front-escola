import { FastifyInstance } from "fastify";
import { DisciplinaUseCase } from "../usecases/disciplina";
import { DisciplinaCreate } from "../interface/disciplina";

export async function disciplinaRoutes(fastify: FastifyInstance) {
  const disciplinaUseCase = new DisciplinaUseCase();

  fastify.post<{ Body: DisciplinaCreate }>("/", async (request, reply) => {
    const { nome, carga_horaria } = request.body;
    try {
      await disciplinaUseCase.create({ nome, carga_horaria });
      return reply.status(201).send({ message: "Disciplina criada com sucesso" });
    } catch (error) {
      reply.status(500).send(error);
    }
  });

  fastify.get("/", async (request, reply) => {
    try {
      const data = await disciplinaUseCase.findAll();
      return reply.status(200).send(data);
    } catch (error) {
      reply.status(500).send({ error: "Erro ao buscar disciplinas" });
    }
  });

  fastify.get<{ Params: { id: string } }>("/:id", async (request, reply) => {
    const { id } = request.params;
    try {
      const data = await disciplinaUseCase.findById(Number(id));
      if (!data) {
        return reply.status(404).send({ message: "Disciplina não encontrada" });
      }
      return reply.status(200).send(data);
    } catch (error) {
      reply.status(500).send({ error: "Erro ao buscar disciplina" });
    }
  });

  fastify.put<{ Params: { id: string }; Body: DisciplinaCreate }>(
    "/:id",
    async (request, reply) => {
      const { id } = request.params;
      const { nome, carga_horaria } = request.body;
      try {
        await disciplinaUseCase.update(Number(id), { nome, carga_horaria });
        return reply.status(200).send({ message: "Disciplina atualizada" });
      } catch (error) {
        reply.status(500).send({ error: "Erro ao atualizar disciplina" });
      }
    }
  );

  fastify.delete<{ Params: { id: string } }>("/:id", async (request, reply) => {
    const { id } = request.params;
    try {
      await disciplinaUseCase.delete(Number(id));
      return reply.status(204).send();
    } catch (error) {
      reply.status(500).send({ error: "Erro ao remover disciplina" });
    }
  });
}