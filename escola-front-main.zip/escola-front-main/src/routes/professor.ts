import { FastifyInstance } from "fastify";
import { ProfessorUseCase } from "../usecases/professor";
import { ProfessorCreate } from "../interface/professor";

export async function professorRoutes(fastify: FastifyInstance) {
  const professorUseCase = new ProfessorUseCase();

  fastify.post<{ Body: ProfessorCreate }>("/", async (request, reply) => {
    const { nome, cpf, especialidade } = request.body;
    try {
      await professorUseCase.create({ nome, cpf, especialidade });
      return reply
        .status(201)
        .send({ message: "Professor criado com sucesso" });
    } catch (error) {
      reply.send(error);
    }
  });

  fastify.get("/", async (request, reply) => {
    try {
      const data = await professorUseCase.findAll();
      return reply.status(200).send(data);
    } catch (error) {
      reply.send(error);
    }
  });

  fastify.get<{ Params: { id: string } }>("/:id", async (request, reply) => {
    const { id } = request.params;
    try {
      const data = await professorUseCase.findById(Number(id));
      if (!data) {
        return reply.status(404).send({ message: "Professor não encontrado" });
      }
      return reply.status(200).send(data);
    } catch (error) {
      reply.send(error);
    }
  });

  fastify.put<{ Params: { id: string }; Body: ProfessorCreate }>(
    "/:id",
    async (request, reply) => {
      const { id } = request.params;
      const { nome, cpf, especialidade } = request.body;
      try {
        const data = await professorUseCase.update(Number(id), {
          nome,
          cpf,
          especialidade,
        });
        return reply.status(200).send({ message: "Professor atualizado" });
      } catch (error) {
        reply.send(error);
      }
    }
  );

  fastify.delete<{ Params: { id: string } }>("/:id", async (request, reply) => {
    const { id } = request.params;
    try {
      await professorUseCase.delete(Number(id));
      return reply.status(204).send({ message: "Professor removido" });
    } catch (error) {
      reply.send(error);
    }
  });
}
