import { FastifyInstance } from "fastify";
import { MatriculaUseCase } from "../usecases/matricula";
import { MatriculaCreate } from "../interface/matricula";

export async function matriculaRoutes(fastify: FastifyInstance) {
  const matriculaUseCase = new MatriculaUseCase();

  fastify.post<{ Body: MatriculaCreate }>("/", async (request, reply) => {
    try {
      const matricula = await matriculaUseCase.create(request.body);
      return reply.status(201).send(matricula);
    } catch (error: any) {
      return reply.status(400).send({ error: error.message });
    }
  });

  fastify.get("/", async (request, reply) => {
    try {
      const matriculas = await matriculaUseCase.findAll();
      return reply.status(200).send(matriculas);
    } catch (error) {
      return reply.status(500).send({ error: "Erro ao buscar matrículas" });
    }
  });

  fastify.get<{ Params: { id: string } }>("/:id", async (request, reply) => {
    try {
      const matricula = await matriculaUseCase.findById(Number(request.params.id));
      if (!matricula) {
        return reply.status(404).send({ error: "Matrícula não encontrada" });
      }
      return reply.status(200).send(matricula);
    } catch (error) {
      return reply.status(500).send({ error: "Erro ao buscar matrícula" });
    }
  });

  fastify.put<{ Params: { id: string }; Body: MatriculaCreate }>(
    "/:id",
    async (request, reply) => {
      try {
        const matricula = await matriculaUseCase.update(
          Number(request.params.id),
          request.body
        );
        return reply.status(200).send(matricula);
      } catch (error: any) {
        return reply.status(400).send({ error: error.message });
      }
    }
  );

  fastify.delete<{ Params: { id: string } }>("/:id", async (request, reply) => {
    try {
      await matriculaUseCase.delete(Number(request.params.id));
      return reply.status(204).send();
    } catch (error) {
      return reply.status(500).send({ error: "Erro ao remover matrícula" });
    }
  });
}