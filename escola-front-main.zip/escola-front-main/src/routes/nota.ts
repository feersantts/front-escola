import { FastifyInstance } from "fastify";
import { NotaUseCase } from "../usecases/nota";
import { NotaCreate, Bimestre } from "../interface/nota";

export async function notaRoutes(fastify: FastifyInstance) {
  const notaUseCase = new NotaUseCase();

  fastify.post<{ Body: NotaCreate }>("/", async (request, reply) => {
    try {
      const nota = await notaUseCase.create(request.body);
      return reply.status(201).send(nota);
    } catch (error: any) {
      return reply.status(400).send({ error: error.message });
    }
  });

  fastify.get("/", async (request, reply) => {
    try {
      const { aluno_id, disciplina_id } = request.query as {
        aluno_id?: string;
        disciplina_id?: string;
      };

      if (aluno_id && disciplina_id) {
        const notas = await notaUseCase.findByAlunoDisciplina(
          Number(aluno_id),
          Number(disciplina_id)
        );
        return reply.status(200).send(notas);
      }

      return reply.status(400).send({ error: "Parâmetros aluno_id e disciplina_id são necessários" });
    } catch (error: any) {
      return reply.status(500).send({ error: error.message });
    }
  });

  fastify.get<{ Params: { id: string } }>("/:id", async (request, reply) => {
    try {
      const nota = await notaUseCase.findById(Number(request.params.id));
      if (!nota) {
        return reply.status(404).send({ error: "Nota não encontrada" });
      }
      return reply.status(200).send(nota);
    } catch (error: any) {
      return reply.status(500).send({ error: error.message });
    }
  });

  fastify.put<{ Params: { id: string }; Body: NotaCreate }>(
    "/:id",
    async (request, reply) => {
      try {
        const nota = await notaUseCase.update(
          Number(request.params.id),
          request.body
        );
        return reply.status(200).send(nota);
      } catch (error: any) {
        return reply.status(400).send({ error: error.message });
      }
    }
  );

  fastify.delete<{ Params: { id: string } }>("/:id", async (request, reply) => {
    try {
      await notaUseCase.delete(Number(request.params.id));
      return reply.status(204).send();
    } catch (error: any) {
      return reply.status(500).send({ error: error.message });
    }
  });
}