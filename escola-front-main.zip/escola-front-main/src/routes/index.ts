import { FastifyInstance } from 'fastify';
import { alunoRoutes } from './aluno';
import { turmaRoutes } from './turma';
import { professorRoutes } from './professor';
import { matriculaRoutes } from './matricula';
import { disciplinaRoutes } from './disciplina';
import { notaRoutes } from './nota';

export function registerRoutes(app: FastifyInstance) {
  app.register(alunoRoutes, { prefix: '/aluno' });
  app.register(turmaRoutes, { prefix: '/turma' });
  app.register(professorRoutes, { prefix: '/professor' });
  app.register(matriculaRoutes, { prefix: '/matricula' });
  app.register(disciplinaRoutes, { prefix: '/disciplina' });
  app.register(notaRoutes, { prefix: '/nota' });
}