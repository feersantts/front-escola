import { FastifyInstance } from "fastify";
import { TurmaUseCase } from "../usecases/turma";
import { TurmaCreate } from "../interface/turma";

export async function turmaRoutes(fastify: FastifyInstance) {
  const turmaUseCase = new TurmaUseCase();

  fastify.post<{ Body: TurmaCreate }>("/", async (request, reply) => {
    const { nome, ano, professor_id, disciplina_id } = request.body;
    try {
      await turmaUseCase.create({ nome, ano, professor_id, disciplina_id });
      return reply.status(201).send({ message: "Turma criada com sucesso" });
    } catch (error) {
      console.log(error);
      reply.status(400).send({ error: "Erro ao criar turma" });
    }
  });

  fastify.get("/", async (request, reply) => {
    try {
      const data = await turmaUseCase.findAll();
      return reply.status(200).send(data);
    } catch (error) {
      reply.status(400).send({ error: "Erro ao buscar turmas" });
    }
  });

  fastify.get<{ Params: { id: string } }>("/:id/alunos", async (request, reply) => {
    const { id } = request.params;
    try {
      const data = await turmaUseCase.findAllAlunosByTurma(Number(id));
      return reply.status(200).send(data);
    } catch (error) {
      reply.status(400).send({ error: "Erro ao buscar turmas" });
    }
  });

  fastify.get<{ Params: { id: string } }>("/:id", async (request, reply) => {
    const { id } = request.params;
    try {
      const data = await turmaUseCase.findById(Number(id));
      if (!data) {
        return reply.status(404).send({ message: "Turma não encontrada" });
      }
      return reply.status(200).send(data);
    } catch (error) {
      reply.status(400).send({ error: "Erro ao buscar turma" });
    }
  });

  fastify.put<{ Params: { id: string }; Body: TurmaCreate }>(
    "/:id",
    async (request, reply) => {
      const { id } = request.params;
      const { nome, ano, professor_id, disciplina_id } = request.body;
      try {
        await turmaUseCase.update(Number(id), {
          nome,
          ano,
          professor_id,
          disciplina_id,
        });
        return reply.status(200).send({ message: "Turma atualizada" });
      } catch (error) {
        reply.status(400).send({ error: "Erro ao atualizar turma" });
      }
    }
  );

  fastify.delete<{ Params: { id: string } }>("/:id", async (request, reply) => {
    const { id } = request.params;
    try {
      await turmaUseCase.delete(Number(id));
      return reply.status(204).send();
    } catch (error) {
      reply.status(400).send({ error: "Erro ao remover turma" });
    }
  });
}
