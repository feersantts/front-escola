import { FastifyInstance } from "fastify";
import { AlunoUseCase } from "../usecases/aluno";
import { AlunoCreate } from "../interface/aluno";
export async function alunoRoutes(fastify: FastifyInstance) {
  const alunoUseCase = new AlunoUseCase();

  fastify.post<{ Body: AlunoCreate }>(
    "/",
    // {
    //   schema: {
    //     body: {
    //       type: "object",
    //       required: ["nome", "data_nascimento", "telefone", "responsavel"],
    //       properties: {
    //         nome: { type: "string" },
    //         data_nascimento: { type: "string" },
    //         telefone: { type: "string" },
    //         responsavel: { type: "string" },
    //       },
    //     },
    //   },
    // },
    async (request, reply) => {
      const aluno = request.body;
      try {
        await alunoUseCase.create(aluno);
        return reply.status(201).send({ message: "Aluno criado com sucesso" });
      } catch (error) {
        reply.status(400).send(error);
      }
    }
  );

  fastify.get("/", async (request, reply) => {
    try {
      const data = await alunoUseCase.findAll();
      return reply.status(200).send(data);
    } catch (error) {
      reply.status(400).send(error);
    }
  });

  fastify.get<{ Params: { id: string } }>("/:id", async (request, reply) => {
    const { id } = request.params;
    try {
      const data = await alunoUseCase.findById(Number(id));
      if (!data) {
        return reply.status(404).send({ message: "Aluno não encontrado" });
      }
      return reply.status(200).send(data);
    } catch (error) {
      reply.status(400).send(error);
    }
  });

  fastify.put<{ Params: { id: string }; Body: AlunoCreate }>(
    "/:id",
    async (request, reply) => {
      const { id } = request.params;
      const aluno = request.body;
      try {
        const data = await alunoUseCase.update(Number(id), aluno);
        return reply.status(200).send({ message: "Aluno atualizado com sucesso" });
      } catch (error) {
        reply.status(400).send(error);
      }
    }
  );

  fastify.delete<{ Params: { id: string } }>("/:id", async (request, reply) => {
    const { id } = request.params;
    try {
      await alunoUseCase.delete(Number(id));
      return reply.status(204).send({ message: "Aluno removido com sucesso" });
    } catch (error) {
      reply.status(400).send(error);
    }
  });
}
