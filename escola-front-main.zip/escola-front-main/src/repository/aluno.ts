import { prisma } from "../db/client";
import { Aluno, AlunoCreate, AlunoRepository } from "../interface/aluno";

export class AlunoRepositoryPrisma implements AlunoRepository {
  async create(aluno: AlunoCreate): Promise<Aluno> {
    console.log("aluno AlunoRepositoryPrisma:", aluno);
    return await prisma.aluno.create({
      data: {
        nome: aluno.nome,
        data_nascimento: aluno.data_nascimento,
        telefone: aluno.telefone,
        responsavel: aluno.responsavel,
      },
    });
  }

  async findAll(): Promise<Aluno[]> {
    return await prisma.aluno.findMany();
  }

  async findById(id: number): Promise<Aluno | null> {
    return await prisma.aluno.findUnique({
      where: { id },
    });
  }

  async exists(id: number): Promise<boolean> {
    const aluno = await prisma.aluno.findUnique({
      where: { id },
      select: { id: true },
    });
    return !!aluno;
  }

  async update(id: number, aluno: AlunoCreate): Promise<Aluno> {
    return await prisma.aluno.update({
      where: { id },
      data: {
        ...aluno,
        data_nascimento: aluno.data_nascimento,
      },
    });
  }

  async delete(id: number): Promise<void> {
    await prisma.aluno.delete({
      where: { id },
    });
  }
}
