import { prisma } from "../db/client";
import {
  Matricula,
  MatriculaCreate,
  MatriculaRepository,
} from "../interface/matricula";

export class MatriculaRepositoryPrisma implements MatriculaRepository {
  async create(matricula: MatriculaCreate): Promise<Matricula> {
    return await prisma.matricula.create({
      data: { ...matricula },
    });
  }

  async findAll(): Promise<any[]> {
    try {
      return await prisma.matricula.findMany({
        include: {
          aluno: {
            select: {
              nome: true,
            },
          },
          turma: {
            select: {
              nome: true,
            },
          },
        }
      });
    } catch (error) {
      console.error("Error fetching all matriculas:", error);
      throw new Error("Error fetching all matriculas");
    }
  }

  async findById(id: number): Promise<Matricula | null> {
    return await prisma.matricula.findUnique({
      where: { id },
    });
  }

  async findByAlunoAndTurma(
    aluno_id: number,
    turma_id: number
  ): Promise<Matricula | null> {
    return await prisma.matricula.findFirst({
      where: {
        aluno_id,
        turma_id,
      },
    });
  }

  async update(id: number, matricula: MatriculaCreate): Promise<Matricula> {
    return await prisma.matricula.update({
      where: { id },
      data: { ...matricula },
    });
  }

  async delete(id: number): Promise<void> {
    await prisma.matricula.delete({
      where: { id },
    });
  }
}
