import { prisma } from "../db/client";
import {
  Disciplina,
  DisciplinaCreate,
  DisciplinaRepository,
} from "../interface/disciplina";

export class DisciplinaRepositoryPrisma implements DisciplinaRepository {
  async create(disciplina: DisciplinaCreate): Promise<Disciplina> {
    return await prisma.disciplina.create({
      data: disciplina,
    });
  }

  async findAll(): Promise<Disciplina[]> {
    return await prisma.disciplina.findMany();
  }

  async findById(id: number): Promise<Disciplina | null> {
    return await prisma.disciplina.findUnique({
      where: { id },
    });
  }

  async exists(id: number): Promise<boolean> {
    const disciplina = await prisma.disciplina.findUnique({
      where: { id },
      select: { id: true },
    });
    return !!disciplina;
  }

  async update(id: number, disciplina: DisciplinaCreate): Promise<Disciplina> {
    return await prisma.disciplina.update({
      where: { id },
      data: disciplina,
    });
  }

  async delete(id: number): Promise<void> {
    await prisma.disciplina.delete({
      where: { id },
    });
  }
}
