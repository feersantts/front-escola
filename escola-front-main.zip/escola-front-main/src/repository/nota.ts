import { prisma } from "../db/client";
import { Nota, NotaCreate, NotaRepository, Bimestre } from "../interface/nota";

export class NotaRepositoryPrisma implements NotaRepository {
  async create(nota: NotaCreate): Promise<Nota> {
    try {
      return await prisma.nota.create({
        data: { ...nota },
      });
    } catch (error) {
      throw new Error("Erro ao criar nota: " + error);
    }
  }

  async findById(id: number): Promise<Nota | null> {
    return await prisma.nota.findUnique({
      where: { id },
    });
  }

  async findByAlunoDisciplina(
    aluno_id: number,
    disciplina_id: number
  ): Promise<Nota[]> {
    return await prisma.nota.findMany({
      where: {
        aluno_id,
        disciplina_id,
      },
    });
  }

  async findByAlunoDisciplinaBimestre(
    aluno_id: number,
    disciplina_id: number,
    bimestre: Bimestre
  ): Promise<Nota | null> {
    return await prisma.nota.findFirst({
      where: {
        aluno_id,
        disciplina_id,
        bimestre,
      },
    });
  }

  async update(id: number, nota: NotaCreate): Promise<Nota> {
    return await prisma.nota.update({
      where: { id },
      data: { ...nota },
    });
  }

  async delete(id: number): Promise<void> {
    await prisma.nota.delete({
      where: { id },
    });
  }
}
