import { prisma } from "../db/client";
import {
  Professor,
  ProfessorCreate,
  ProfessorRepository,
} from "../interface/professor";

export class ProfessorRepositoryPrisma implements ProfessorRepository {
  async create(prof: ProfessorCreate) {
    return await prisma.professor.create({
      data: { ...prof },
    });
  }

  async findAll() {
    return await prisma.professor.findMany();
  }

  async findById(id: number) {
    return await prisma.professor.findUnique({
      where: { id },
      select: { id: true, nome: true },
    });
  }

  async exists(id: number) {
    const professor = await prisma.professor.findUnique({
      where: { id },
      select: { id: true },
    });
    return !!professor;
  }

  async update(id: number, prof: ProfessorCreate) {
    return await prisma.professor.update({
      where: { id },
      data: { ...prof },
    });
  }

  async delete(id: number) {
    await prisma.professor.delete({
      where: { id },
    });
  }
}
