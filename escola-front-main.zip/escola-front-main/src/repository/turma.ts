import { prisma } from "../db/client";
import { Turma, TurmaCreate, TurmaRepository } from "../interface/turma";

export class TurmaRepositoryPrisma implements TurmaRepository {
  async create(turma: TurmaCreate): Promise<Turma> {
    console.log(`repository`, turma);
    try {
      return await prisma.turma.create({
        data: turma,
      });
    } catch (error: any) {
      throw new Error("Erro ao criar turma: ", error);
    }
  }

  async findAll(): Promise<Turma[]> {
    return await prisma.turma.findMany({
      include: {
        disciplina: {
          select: {
            nome: true,
          },
        },
        professor: {
          select: {
            nome: true,
          },
        },
      },
    });
  }

  async findById(id: number): Promise<Turma | null> {
    return await prisma.turma.findUnique({
      where: { id },
    });
  }

  async findAllAlunosByTurma(id: number): Promise<Turma | null> {
    return await prisma.turma.findUnique({
      where: { id },
      include: {
        matriculas: {
          include: {
            aluno: {
              select: {
                nome: true,
              },
            },
          },
        },
      },
    });
  }

  async exists(id: number): Promise<boolean> {
    const turma = await prisma.turma.findUnique({
      where: { id },
      select: { id: true },
    });
    return !!turma;
  }

  async update(id: number, turma: TurmaCreate): Promise<Turma> {
    return await prisma.turma.update({
      where: { id },
      data: turma,
    });
  }

  async delete(id: number): Promise<void> {
    await prisma.turma.delete({
      where: { id },
    });
  }
}
