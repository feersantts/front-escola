import { Professor, ProfessorCreate, ProfessorRepository } from "../interface/professor";
import { ProfessorRepositoryPrisma } from "../repository/professor";

export class ProfessorUseCase {
  private ProfessorRepository: ProfessorRepository;

  constructor() {
    this.ProfessorRepository = new ProfessorRepositoryPrisma();
  }

  async create(data: ProfessorCreate): Promise<Professor> {
    const prof = await this.ProfessorRepository.create(data);

    return prof;
  }

  async findById(id: number): Promise<Professor | null> {
    const prof = await this.ProfessorRepository.findById(id);

    return prof;
  }

  async findAll(): Promise<Professor[]> {
    const prof = await this.ProfessorRepository.findAll();

    return prof;
  }

  async update(id: number, prof: ProfessorCreate): Promise<Professor> {
    const profUpdated = await this.ProfessorRepository.update(id, prof);

    return profUpdated;
  }

  async delete(id: number): Promise<void> {
    await this.ProfessorRepository.delete(id);
  }
}