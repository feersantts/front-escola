import { Disciplina, DisciplinaCreate, DisciplinaRepository } from "../interface/disciplina";
import { DisciplinaRepositoryPrisma } from "../repository/disciplina";

export class DisciplinaUseCase {
  private disciplinaRepository: DisciplinaRepository;

  constructor() {
    this.disciplinaRepository = new DisciplinaRepositoryPrisma();
  }

  async create(data: DisciplinaCreate): Promise<Disciplina> {
    return await this.disciplinaRepository.create(data);
  }

  async findById(id: number): Promise<Disciplina | null> {
    return await this.disciplinaRepository.findById(id);
  }

  async findAll(): Promise<Disciplina[]> {
    return await this.disciplinaRepository.findAll();
  }

  async update(id: number, disciplina: DisciplinaCreate): Promise<Disciplina> {
    return await this.disciplinaRepository.update(id, disciplina);
  }

  async delete(id: number): Promise<void> {
    await this.disciplinaRepository.delete(id);
  }
}