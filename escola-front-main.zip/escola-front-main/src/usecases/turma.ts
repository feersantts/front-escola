import { DisciplinaRepository } from "../interface/disciplina";
import { ProfessorRepository } from "../interface/professor";
import { Turma, TurmaCreate, TurmaRepository } from "../interface/turma";
import { DisciplinaRepositoryPrisma } from "../repository/disciplina";
import { ProfessorRepositoryPrisma } from "../repository/professor";
import { TurmaRepositoryPrisma } from "../repository/turma";

export class TurmaUseCase {
  private turma: TurmaRepository;
  private professor: ProfessorRepository;
  private diciplina: DisciplinaRepository;

  constructor() {
    this.turma = new TurmaRepositoryPrisma();
    this.professor = new ProfessorRepositoryPrisma();
    this.diciplina = new DisciplinaRepositoryPrisma();
  }

  async create(data: TurmaCreate): Promise<Turma> {
    const [professorExists, diciplinaExists] = await Promise.all([
      this.professor.exists(data.professor_id),
      this.diciplina.exists(data.disciplina_id),
    ]);

    if (!professorExists) throw new Error("Professor não encontrado");
    if (!diciplinaExists) throw new Error("Diciplina não encontrada");

    return await this.turma.create(data);
  }

  async findById(id: number): Promise<Turma | null> {
    return await this.turma.findById(id);
  }

  async findAll(): Promise<Turma[]> {
    return await this.turma.findAll();
  }

  async findAllAlunosByTurma(id: number): Promise<Turma[]> {
    return await this.turma.findAllAlunosByTurma(id);
  }

  async update(id: number, data: TurmaCreate): Promise<Turma> {
    const [professorExists, diciplinaExists] = await Promise.all([
      this.professor.exists(data.professor_id),
      this.diciplina.exists(data.disciplina_id),
    ]);

    if (!professorExists) throw new Error("Professor não encontrado");
    if (!diciplinaExists) throw new Error("Diciplina não encontrada");

    return await this.turma.update(id, data);
  }

  async delete(id: number): Promise<void> {
    await this.turma.delete(id);
  }
}
