import { AlunoRepository } from "../interface/aluno";
import {
  Matricula,
  MatriculaCreate,
  MatriculaRepository,
} from "../interface/matricula";
import { TurmaRepository } from "../interface/turma";
import { AlunoRepositoryPrisma } from "../repository/aluno";
import { MatriculaRepositoryPrisma } from "../repository/matricula";
import { TurmaRepositoryPrisma } from "../repository/turma";

export class MatriculaUseCase {
  private matricula: MatriculaRepository;
  private aluno: AlunoRepository;
  private turma: TurmaRepository;

  constructor() {
    this.matricula = new MatriculaRepositoryPrisma();
    this.aluno = new AlunoRepositoryPrisma();
    this.turma = new TurmaRepositoryPrisma();
  }

  async create(data: MatriculaCreate): Promise<Matricula> {
    const [alunoExists, turmaExists] = await Promise.all([
      this.aluno.exists(data.aluno_id),
      this.turma.exists(data.turma_id),
    ]);

    if (!alunoExists) throw new Error("Aluno não encontrado");
    if (!turmaExists) throw new Error("Turma não encontrada");

    const matriculaExists = await this.matricula.findByAlunoAndTurma(
      data.aluno_id,
      data.turma_id
    );

    if (matriculaExists) {
      throw new Error("Aluno já matriculado nesta turma");
    }

    return await this.matricula.create(data);
  }

  async findById(id: number): Promise<Matricula | null> {
    return await this.matricula.findById(id);
  }

  async findAll(): Promise<Matricula[]> {
    return await this.matricula.findAll();
  }

  async update(id: number, data: MatriculaCreate): Promise<Matricula> {
    return await this.matricula.update(id, data);
  }

  async delete(id: number): Promise<void> {
    await this.matricula.delete(id);
  }
}
