import { Aluno, AlunoCreate, AlunoRepository } from "../interface/aluno";
import { AlunoRepositoryPrisma } from "../repository/aluno";
export class AlunoUseCase {
  private AlunoRepository: AlunoRepository;

  constructor() {
    this.AlunoRepository = new AlunoRepositoryPrisma();
  }

  async create(data: AlunoCreate): Promise<Aluno> {
    const aluno = await this.AlunoRepository.create(data);
    return aluno;
  }

  async findById(id: number): Promise<Aluno | null> {
    const aluno = await this.AlunoRepository.findById(id);
    return aluno;
  }

  async findAll(): Promise<Aluno[]> {
    const aluno = await this.AlunoRepository.findAll();
    return aluno;
  }

  async update(id: number, aluno: AlunoCreate): Promise<Aluno> {
    const alunoUpdated = await this.AlunoRepository.update(id, aluno);
    return alunoUpdated;
  }

  async delete(id: number): Promise<void> {
    await this.AlunoRepository.delete(id);
  }
}
