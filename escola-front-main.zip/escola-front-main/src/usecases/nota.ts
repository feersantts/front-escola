import { AlunoRepository } from "../interface/aluno";
import { DisciplinaRepository } from "../interface/disciplina";
import { Nota, NotaCreate, NotaRepository, Bimestre } from "../interface/nota";
import { AlunoRepositoryPrisma } from "../repository/aluno";
import { DisciplinaRepositoryPrisma } from "../repository/disciplina";
import { NotaRepositoryPrisma } from "../repository/nota";

export class NotaUseCase {
  private nota: NotaRepository;
  private aluno: AlunoRepository;
  private diciplina: DisciplinaRepository;

  constructor() {
    this.nota = new NotaRepositoryPrisma();
    this.aluno = new AlunoRepositoryPrisma();
    this.diciplina = new DisciplinaRepositoryPrisma();
  }

  async create(data: NotaCreate): Promise<Nota> {
    const [alunoExists, diciplinaExists] = await Promise.all([
      this.aluno.exists(data.aluno_id),
      this.diciplina.exists(data.disciplina_id),
    ]);

    if (!alunoExists) throw new Error("Aluno não encontrado");
    if (!diciplinaExists) throw new Error("Diciplina não encontrada");

    if (data.valor < 0 || data.valor > 10) {
      throw new Error("A nota deve estar entre 0,0 e 10,0");
    }

    const exists = await this.nota.findByAlunoDisciplinaBimestre(
      data.aluno_id,
      data.disciplina_id,
      data.bimestre
    );

    if (exists) {
      throw new Error(
        "Já existe nota cadastrada para este aluno, disciplina e bimestre"
      );
    }

    return await this.nota.create(data);
  }

  async findById(id: number): Promise<Nota | null> {
    return await this.nota.findById(id);
  }

  async findByAlunoDisciplina(
    aluno_id: number,
    disciplina_id: number
  ): Promise<Nota[]> {
    return await this.nota.findByAlunoDisciplina(aluno_id, disciplina_id);
  }

  async update(id: number, data: NotaCreate): Promise<Nota> {
    const [alunoExists, diciplinaExists] = await Promise.all([
      this.aluno.exists(data.aluno_id),
      this.diciplina.exists(data.disciplina_id),
    ]);

    if (!alunoExists) throw new Error("Aluno não encontrado");
    if (!diciplinaExists) throw new Error("Diciplina não encontrada");

    if (data.valor < 0 || data.valor > 10) {
      throw new Error("A nota deve estar entre 0,0 e 10,0");
    }

    return await this.nota.update(id, data);
  }

  async delete(id: number): Promise<void> {
    await this.nota.delete(id);
  }
}
